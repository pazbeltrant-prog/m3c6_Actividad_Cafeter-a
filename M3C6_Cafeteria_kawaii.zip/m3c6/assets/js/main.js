/* =========================================

   LOGICA DEL SITIO - AROMA & GRANO

   Manipulación de estados SMACSS (is-*)

   ========================================= */



document.addEventListener('DOMContentLoaded', () => {

   

    // ---------------------------------------------

    // 1. EFECTO SCROLL EN HEADER

    // Objetivo: Añadir sombra cuando el usuario baja

    // ---------------------------------------------

    const header = document.querySelector('.l-header');



    window.addEventListener('scroll', () => {

        // Si bajamos más de 50px, añadimos la clase de estado

        if (window.scrollY > 50) {

            header.classList.add('is-scrolled');

        } else {

            header.classList.remove('is-scrolled');

        }

    });



    // ---------------------------------------------

    // 2. INTERACCIÓN BOTONES DE PEDIDO

    // Objetivo: Dar feedback visual al hacer clic

    // ---------------------------------------------

   

    // Seleccionamos todos los botones pequeños de las cards

    const orderButtons = document.querySelectorAll('.card .btn-small');



    orderButtons.forEach(btn => {

        btn.addEventListener('click', (e) => {

            const currentBtn = e.target;

            const originalText = currentBtn.innerText;



            // Evitamos que den clic muchas veces seguidas

            if(currentBtn.classList.contains('is-added')) return;



            // Cambiamos el estado visual

            currentBtn.classList.add('is-added');

            currentBtn.innerText = "¡Agregado! ✔";



            // Simulamos que pasaron 2 segundos y volvemos a la normalidad

            setTimeout(() => {

                currentBtn.classList.remove('is-added');

                currentBtn.innerText = originalText;

            }, 2000);

        });

    });



});



/// efecto alerta toast//
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.card-button');

    cards.forEach(card => {
        card.addEventListener('click', function() {
            const id = this.id;
            const servicio = this.querySelector('.service-name').innerText;
            const icono = this.querySelector('.card-image-container').parentNode.innerText.includes('☕') ? '☕' : 
                          id === 'reposteria-card' ? '🥐' : 
                          id === 'karaoke-card' ? '🎤' : '📖';

            // Definir clase de color según el ID
            let typeClass = '';
            if(id === 'especialidad-card') typeClass = 'toast-cafe';
            if(id === 'reposteria-card') typeClass = 'toast-reposteria';
            if(id === 'karaoke-card') typeClass = 'toast-karaoke';
            if(id === 'manga-card') typeClass = 'toast-manga';

            // Ejecutar la notificación
            showToast(`${icono} ¡Genial gran elección! Abriendo sección ${servicio}...`, typeClass);
            
            // Efecto visual de clic en la card
            this.style.transform = "scale(0.95)";
            setTimeout(() => this.style.transform = "", 150);
        });
    });
});

function showToast(message, typeClass) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    
    toast.className = `custom-toast ${typeClass}`;
    toast.innerHTML = `<span>${message}</span>`;
    
    container.appendChild(toast);

    // Desaparecer después de 3 segundos
    setTimeout(() => {
        toast.classList.add('toast-fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}


function openNav() {
    document.getElementById("mySidenav").style.width = "280px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}