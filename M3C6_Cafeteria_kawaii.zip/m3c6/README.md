requisito tipo  landing page
servicios  -  faltan imagenes y efectos.
-cafe y bebida-listo
-pasteleria-listo
-karaoke y trivia-trabajando para usted <3 
-Club de Lectura mangas- en proceso comadre <3 


-seccion de favoritos - falta  podria ser promociones por el mes de enero nose 25 % descuento en un pastel o cafe 
los dias miercoles o presentando tu tne que se yo xd para una promo escolar universitaria.


opiniones  y comentarios - aun no incluido (propongo poner que personajes de anime digan cosas y ponerle nose que tanjiro dijo que estaban buenas las anvorguesas xd o que la anya dijo que estaban peor que la comida de la yor T.T xD )
formulario de contacto - aun no incluido 
boton para descargar un menu de la cafeteria-aun no incluido-  creare un menu ficticio 
slider con imagenes-  tenemos el servidor para subir imagenes  falta crear el slide y elegir imagenes 
Sistema de reservas   (propuesta) 
carrito de compra   (tipo uber eats ?)
horarios            (no habiamos includo eso :3 )
cursor de anime unicamente para pc y tablet , (pensaba en una anya o pastel pero una vez todo listo )
 mapa de las sucursales en temuco y que tenga unos puntos en rojos para georeferencia.  (viña esta muy trillado e.e )